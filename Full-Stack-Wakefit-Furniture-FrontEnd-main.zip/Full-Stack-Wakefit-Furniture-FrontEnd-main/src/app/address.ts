

export class Address {
  addressId!: number;
  landmark!: string;
  address!: string;
  city!: string;
  state!: string;
  pincode!: string;
  
}