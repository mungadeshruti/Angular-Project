export class Product {
    productId!:number;
    name!:string; 
    description!: string;
    price!:number;
    images!:string;
    stockQuantity!:number;

}

