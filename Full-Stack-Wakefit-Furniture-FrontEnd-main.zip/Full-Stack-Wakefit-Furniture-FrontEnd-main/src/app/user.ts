
export class User {
  userId!: number;
  userName!: string;
  password!: string;
  email!: string;
  firstName!: string;
  lastName!: string;
  mobNo!: string;
  role!: string;

}