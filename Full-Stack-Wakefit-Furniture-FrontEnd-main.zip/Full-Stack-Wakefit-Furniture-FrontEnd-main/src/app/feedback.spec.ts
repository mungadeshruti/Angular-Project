import { Feedback } from './feedback';

describe('Product', () => {
  it('should create an instance', () => {
    expect(new Feedback()).toBeTruthy();
  });
});
