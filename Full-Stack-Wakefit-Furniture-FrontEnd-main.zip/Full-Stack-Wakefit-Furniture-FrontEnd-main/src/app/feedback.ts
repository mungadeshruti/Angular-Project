
export class Feedback {
    feedbackId!: number;
    rating!: number;
    comment!: string;
    feedbackDate!: Date;
}
