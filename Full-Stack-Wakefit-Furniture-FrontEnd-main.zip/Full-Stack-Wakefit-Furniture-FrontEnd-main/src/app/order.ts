export class Order {
  orderId!: number;
  orderDate!: Date;
  totalAmount!: number;
  paymentStatus!: string;
  orderStatus!: string;

  }
